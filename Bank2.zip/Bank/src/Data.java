/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author KINSHUK
 */
public class Data {
    private String name;
    private String branch;
    private String gender;
    private String emailid;
    private int balance;
    private String password;
    private String accno;
    static int c;
    

    public Data(String name,String branch,String gender,String emailid,String password) {
        this.name=name;
        this.branch=branch;
        this.gender=gender;
        this.emailid=emailid;
        this.password=password;
        balance=0;
        accno=branch.substring(0,3)+("0000000"+(++c)).substring((c+"").length());
        
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAccno() {
        return accno;
    }

    public void setAccno(String accno) {
        this.accno = accno;
    }

    public static int getC() {
        return c;
    }

    @Override
    public String toString() {
        return "Data{" + "name=" + name + ", branch=" + branch + ", gender=" + gender + ", emailid=" + emailid + ", balance=" + balance + ", password=" + password + ", accno=" + accno + '}';
    }

    public static void setC(int c) {
        Data.c = c;
    }
}

